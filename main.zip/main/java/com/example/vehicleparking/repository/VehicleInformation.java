package com.example.vehicleparking.repository;


import com.example.vehicleparking.entity.Vehicle;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class VehicleInformation {
    private static Set<Vehicle> vehi=new HashSet<>();

    public static void addVehicle(Vehicle v){
        vehi.add(v);
    }
    public static void removeVehicle(String id){
        for(Vehicle v:vehi){
            if(v.getId().equals("id")){
                vehi.remove(v);
                return;
            }
        }
    }
    public void PrintUsers(){
        System.out.println(vehi);
    }
    public static Vehicle findVehicle(String id){
        for(Vehicle v: vehi){
            if(Objects.equals(v.getId(), id)){
                return v;
            }
        }
        return null;
    }


}

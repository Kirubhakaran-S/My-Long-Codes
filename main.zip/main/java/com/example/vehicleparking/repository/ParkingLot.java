package com.example.vehicleparking.repository;


import com.example.vehicleparking.entity.Vehicle;
import com.example.vehicleparking.entity.Slots;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashSet;
import java.util.Set;


public class ParkingLot {
    private static Set<Slots> slotSet = new HashSet<>();
    static{
        for(int i = 1; i <= 100; i++){
            slotSet.add(new Slots(i, "Available", null));
        }

    }

    public static void addSlot(String id,int slot_id){
        for(Slots s:slotSet){
            if(s.getSlot_id()==slot_id){
                s.setStatus("Parked");
                s.setVehicle_id(id);
                return;
            }
        }
    }
    public static void removeSlot(int id){

        for(Slots s:slotSet) {
            if (s.getSlot_id() == id) {
                s.setStatus("Available");
                VehicleInformation.removeVehicle(s.getVehicle_id());
                s.setVehicle_id(null);

            }


        }
    }
    public static int availableSlot(){
        for(Slots s:slotSet){
            if(s.getStatus().equals("Available")){
                return s.getSlot_id();
            }
        }
        return 0;
    }

    public static Set<Slots> showSlot(){
       return slotSet;
        }
    }




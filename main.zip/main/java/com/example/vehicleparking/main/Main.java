package com.example.vehicleparking.main;



import com.example.vehicleparking.repository.ParkingLot;
import com.example.vehicleparking.services.Parking;

import java.util.Scanner;

import static com.example.vehicleparking.services.AddVehicle.addVehi;

public class Main {
    private static Scanner sc=new Scanner(System.in);
    public static void main(String[] args) {
        int user_id;
        String name;
        String vehicle_id;
        String model;
        String type;
        int contact_no;

        System.out.println("***WELCOME***");
        while(true) {
            System.out.println("\n\n1.Park vehicle \n2.Get Vehicle From Parking\n3.Show Slots");
            int i = sc.nextInt();
            if (i == 1) {
                       System.out.print("ID: ");
                        user_id=sc.nextInt();
                        System.out.println("Name: ");
                        name = sc.next();
                        System.out.println("Contact No: ");
                        contact_no=sc.nextInt();
                        System.out.println("Vehicle id:  ");
                        vehicle_id = sc.next();
                        System.out.println("Type: ");
                        type = sc.next();
                        System.out.println("Model: ");
                        model = sc.next();

                       Parking.parkVehicle(user_id,name,contact_no,vehicle_id,type,model);
            } else if (i == 2) {
                System.out.println("Enter the Slot id: ");
                 int slot_id = sc.nextInt();
                Parking.removeVehicle(slot_id);
            }
            else if(i==3){
                Parking.viewSlots();
            }else {
                System.out.println("Wrong Choice !!! Try again");
            }
        }
    }
}
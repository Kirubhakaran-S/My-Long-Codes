package com.example.vehicleparking.services;

import com.example.vehicleparking.entity.Vehicle;
import com.example.vehicleparking.repository.ParkingLot;
import com.example.vehicleparking.repository.VehicleInformation;

public class AddVehicle {
    public static void addVehi(int user_id,String vehicle_id,String Model,String type,int slot_id){
        Vehicle vehi=new Vehicle(user_id,vehicle_id,Model,type,slot_id);
        VehicleInformation.addVehicle(vehi);
    }
}

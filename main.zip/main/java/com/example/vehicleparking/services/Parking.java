
package com.example.vehicleparking.services;

import com.example.vehicleparking.entity.Vehicle;
import com.example.vehicleparking.repository.ParkingLot;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static com.example.vehicleparking.repository.ParkingLot.showSlot;


public class Parking {
    public static void parkVehicle(int user_id, String name, int contact_no, String vehicle_id, String type, String model){

        int slot=ParkingLot.availableSlot();
        if(slot==0){
            System.out.println("No Slot Available");
        }
        else{
            AddVehicle.addVehi(user_id,vehicle_id,type,model,slot);
            ParkingLot.addSlot(vehicle_id,slot);
        }
    }
    public static void removeVehicle(int id){
        ParkingLot.removeSlot(id);
    }

    public static void viewSlots(){
        showSlot();
    }

}
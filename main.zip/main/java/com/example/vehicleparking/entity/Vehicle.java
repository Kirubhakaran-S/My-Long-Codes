
package com.example.vehicleparking.entity;
public class Vehicle {
    int user_id;
    String id;
    String Model;
    String Type;
    int Slot_id;

    public Vehicle(int user_id, String id, String model, String type, int slot_id) {
        this.user_id = user_id;
        this.id = id;
        Model = model;
        Type = type;
        Slot_id = slot_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getModel() {
        return Model;
    }

    public void setModel(String model) {
        Model = model;
    }

    public String getType() {
        return Type;
    }

    public void setType(String type) {
        Type = type;
    }

    public int getSlot_id() {
        return Slot_id;
    }

    public void setSlot_id(int slot_id) {
        Slot_id = slot_id;
    }

    @Override
    public String toString() {
        return "Vehicle{" +
                "user_id=" + user_id +
                ", id='" + id + '\'' +
                ", Model='" + Model + '\'' +
                ", Type='" + Type + '\'' +
                ", Slot_id=" + Slot_id +
                '}';
    }
}


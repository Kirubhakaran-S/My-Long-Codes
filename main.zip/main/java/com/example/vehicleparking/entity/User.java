package com.example.vehicleparking.entity;

public class User {
    int user_id;
    String name;
    int contact_no;
    int vehicle_id;

    public User(int user_id, String name, int contact_no, int vehicle_id) {
        this.user_id = user_id;
        this.name = name;
        this.contact_no = contact_no;
        this.vehicle_id = vehicle_id;
    }

    public int getVehicle_id() {
        return vehicle_id;
    }

    public void setVehicle_id(int vehicle_id) {
        this.vehicle_id = vehicle_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getContact_no() {
        return contact_no;
    }

    public void setContact_no(int contact_no) {
        this.contact_no = contact_no;
    }
}

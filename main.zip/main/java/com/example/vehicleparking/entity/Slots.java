package com.example.vehicleparking.entity;

public class Slots {
    int slot_id;
    String status;
    String vehicle_id;

    public Slots(int slot_id, String status, String vehicle_id) {
        this.slot_id = slot_id;
        this.status = status;
        this.vehicle_id = vehicle_id;
    }

    public int getSlot_id() {
        return slot_id;
    }

    public void setSlot_id(int slot_id) {
        this.slot_id = slot_id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getVehicle_id() {
        return vehicle_id;
    }

    public void setVehicle_id(String vehicle_id) {
        this.vehicle_id = vehicle_id;
    }

    @Override
    public String toString() {
        return "Slots{" +
                "status='" + status + '\'' +
                '}';
    }
}

